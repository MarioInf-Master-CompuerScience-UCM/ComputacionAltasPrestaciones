No he logrado que el compilador ejecute los kernels en mi tarjeta gráfica Intel, ya que no es capaz de reconocerla como un
dispositivo del equipo. Por ello, hay ciertas cosas que no he podido probrar y algún problema que no he sabido resolver,
sin embargo, he aplicado lo expuesto en el tema a lo largo de ambos ejercicios medinate el uso de las pragmas pertinentes,
mostrando al menos, los conocimientos sobre como relizar la ejecución utilizando dispositivos GPU.